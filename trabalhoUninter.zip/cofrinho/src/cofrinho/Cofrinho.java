package cofrinho;

import java.util.ArrayList;

public class Cofrinho {
	private ArrayList<Moeda> listaMoedas = new ArrayList<>();	
	
	
	//Intancia um objeto e adiciona à lista
	public void adicionar(Moeda moeda) {
		listaMoedas.add(moeda);
	}
	
	// recebe um objeto temporário com as mesmas carácterísticas do objeto que deve ser removido da lista
	public void remover(Moeda moeda) {
		//comparamos o objeto temporário com os objetos da lista para remover um objeto da mesma moeda e com o mesmo valor
	 if (moeda instanceof Dolar) {
		 listaMoedas.removeIf(item -> item instanceof Dolar && moeda.valor == item.valor);
	 } else if (moeda instanceof Euro){
		 listaMoedas.removeIf(item -> item instanceof Euro && moeda.valor == item.valor);
	 } else {
		 listaMoedas.removeIf(item -> item instanceof Real && moeda.valor == item.valor);
	 }
	}
	
	//printa as moedas e seus valores
	public void listagemMoedas() {
		if (listaMoedas.isEmpty()) {
			System.out.println("\nO cofre está vazio, adicione moedas para poder listar.");
		} else {
		listaMoedas.forEach(moeda -> 
		moeda.info());
		}
	}
	
	//Incrementa tudo convertido em real e exibe no console
	public void totalConvertido () {
		double total = 0;
		
		for (Moeda moeda : listaMoedas) {
			total += moeda.converter();
		}
		
		System.out.println("Total convertido em reais: " + total);
	}
	
}
