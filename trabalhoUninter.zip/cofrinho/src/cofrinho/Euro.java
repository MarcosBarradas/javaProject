package cofrinho;

public class Euro extends Moeda{

	public Euro(double valor) {
		super(valor);
	}

	@Override
	public void info() {
		System.out.println("Euro: " + valor); //exibe valor da moeda
	}

	@Override
	public double converter() {
		return valor * 6.3; //converte para real
		
	}
		
}
