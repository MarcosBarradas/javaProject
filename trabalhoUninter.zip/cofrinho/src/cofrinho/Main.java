package cofrinho;

/** 
 * @author Marcos Vinicius de Moraes
 * @version 1.0
 * @since 2025-03-24
 * @Professor Leonardo Gomes
 * @discipline Programação Orientada a Objetos
 * @description Esse Programa representa um cofre que exibe um menu com quatro opções:
 * adicionar moedas, remover moedas, listar moedas e mostrar total em real. 
 * Pode adicionar ou remover moedas diferentes de Real, Dólar ou Euro, 
 * assim como exibir todas as moedas já adicionadas ao cofrinho.
 */

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Cofrinho cofrinho = new Cofrinho();
		int opcao;

		do { // loop para manter o menu ativo até o encerramento
			System.out.println("\n===== COFRINHO =====");
			System.out.println("1. Adicionar Moeda");
			System.out.println("2. Remover Moeda");
			System.out.println("3. Listar Moedas");
			System.out.println("4. Exibir total convertido em Real");
			System.out.println("0. Sair");
			System.out.print("Escolha uma opção: ");

			opcao = scanner.nextInt();

			switch (opcao) {
			case 0: //0. encerra programa
				System.out.println("Saindo... obrigado!");
				break;

			case 1: //1. adicionar Moeda
				System.out.println("\nEscolher Moeda: ");
				System.out.println("1. Adicionar Real");
				System.out.println("2. Adicionar Dólar");
				System.out.println("3. Adicionar Euro");
				int moedaEscolhida = scanner.nextInt();

				System.out.println("\nDigite o valor: ");
				double valor = scanner.nextDouble();

				// Filtra para determinar qual moeda deve ser ADICIONADA ao cofre
				if (moedaEscolhida == 1) {
					cofrinho.adicionar(new Real(valor));
				} else if (moedaEscolhida == 2) {
					cofrinho.adicionar(new Dolar(valor));
				} else if (moedaEscolhida == 3) {
					cofrinho.adicionar(new Euro(valor));
				} else {
					System.out.println("\nA opção " + moedaEscolhida + " não existe.");
				}
				break;

			case 2: //2. Remover Moeda
				System.out.println("\nEscolher Moeda: ");
				System.out.println("1. Remover Real");
				System.out.println("2. Remover Dólar");
				System.out.println("3. Remover Euro");
				int moedaExcluida = scanner.nextInt();

				System.out.println("\nDigite o valor: ");
				double moedaRemovida = scanner.nextDouble();

				// Filtra para determinar qual moeda deve ser REMOVIDA do cofre
				if (moedaExcluida == 1) {
					cofrinho.remover(new Real(moedaRemovida));
				} else if (moedaExcluida == 2) {
					cofrinho.remover(new Dolar(moedaRemovida));
				} else if (moedaExcluida == 3) {
					cofrinho.remover(new Euro(moedaRemovida));
				} else {
					System.out.println("A opção " + moedaExcluida + " não existe.");
				}
				break;

			case 3: //3. Listar moedas
				cofrinho.listagemMoedas();
				break;

			case 4: //4. Exibir total convertido em Real
				cofrinho.totalConvertido();
				break;

			default:
				System.out.println("Opção inválida. Tente novamente.");
			}
		} while (opcao != 0);

		scanner.close();

	}
}
